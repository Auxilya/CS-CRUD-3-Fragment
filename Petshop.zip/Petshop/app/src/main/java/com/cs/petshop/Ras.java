package com.cs.petshop;

import java.io.Serializable;

public class Ras implements Serializable {
    private String id;
    private String ras;

    public Ras() {
    }

    public Ras(String id, String ras) {
        this.id = id;
        this.ras = ras;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRas() {
        return ras;
    }

    public void setRas(String ras) {
        this.ras = ras;
    }
}