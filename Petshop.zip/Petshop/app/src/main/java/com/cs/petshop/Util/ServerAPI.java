package com.cs.petshop.Util;

/**
 * Created by hakiki95 on 11/30/2016.
 */

public class ServerAPI {
    public static final String DATK = "http://auxilya.dx.am/website/kucing/getKucing.php";
    public static final String INSK = "http://auxilya.dx.am/website/kucing/createKucing.php";
    public static final String DELK = "http://auxilya.dx.am/website/kucing/deleteKucing.php";
    public static final String UPDK = "http://auxilya.dx.am/website/kucing/updateKucing.php";

    public static final String DATR = "http://auxilya.dx.am/website/ras/getRas.php";
    public static final String INSR = "http://auxilya.dx.am/website/ras/createRas.php";
    public static final String DELR = "http://auxilya.dx.am/website/ras/deleteRas.php";
    public static final String UPDR = "http://auxilya.dx.am/website/ras/updateRas.php";

    public static final String DATW = "http://auxilya.dx.am/website/warna/getWarna.php";
    public static final String INSW = "http://auxilya.dx.am/website/warna/createWarna.php";
    public static final String DELW = "http://auxilya.dx.am/website/warna/deleteWarna.php";
    public static final String UPDW = "http://auxilya.dx.am/website/warna/updateWarna.php";
}
