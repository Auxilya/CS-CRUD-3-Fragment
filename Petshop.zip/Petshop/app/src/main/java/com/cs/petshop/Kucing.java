package com.cs.petshop;

import java.io.Serializable;

public class Kucing implements Serializable {
    private String id;
    private String nama;
    private String ras;
    private String warna;
    private String jenis_kelamin;


    public Kucing() {
    }

    public Kucing(String id, String nama, String ras, String warna, String jenis_kelamin) {
        this.id = id;
        this.nama = nama;
        this.ras = ras;
        this.warna = warna;
        this.jenis_kelamin = jenis_kelamin;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getRas() {
        return ras;
    }

    public void setRas(String ras) {
        this.ras = ras;
    }

    public String getWarna() {
        return warna;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public String getJenis_kelamin() {
        return jenis_kelamin;
    }

    public void setJenis_kelamin(String jenis_kelamin) {
        this.jenis_kelamin = jenis_kelamin;
    }

}
