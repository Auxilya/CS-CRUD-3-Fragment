package com.cs.petshop;

public class Rass {
    private String infoRas;
    private String  id;
    private String ras;

    public Rass() {}

    public Rass(String id, String ras) {
        this.id = id;
        this.ras = ras;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRas() {
        return ras;
    }

    public void setRas(String ras) {
        this.ras = ras;
    }

    public String getInfoRas() {
        return infoRas;
    }

    public void setInfoRas(String infoRass) {
        this.infoRas = infoRas;
    }
}