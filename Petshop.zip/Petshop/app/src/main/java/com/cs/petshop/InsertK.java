package com.cs.petshop;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.cs.petshop.Util.AppController;
import com.cs.petshop.Util.ServerAPI;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class InsertK extends AppCompatActivity {
    EditText id, nama, ras, warna, jenis_kelamin;
    Button btnbatal,btnsimpan;
    ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_datak);

        /*get data from intent*/
        Intent data = getIntent();
        final int update = data.getIntExtra("update",0);
        String intent_id = data.getStringExtra("id");
        String intent_nama = data.getStringExtra("nama");
        String intent_ras = data.getStringExtra("ras");
        String intent_warna = data.getStringExtra("warna");
        String intent_jenis_kelamin = data.getStringExtra("jk");
        /*end get data from intent*/

        id = (EditText) findViewById(R.id.inp_idk);
        nama = (EditText) findViewById(R.id.inp_nama);
        ras = (EditText) findViewById(R.id.inp_rask);
        warna = (EditText) findViewById(R.id.inp_warnak);
        jenis_kelamin = (EditText) findViewById(R.id.inp_jenis_kelamin);
        btnbatal = (Button) findViewById(R.id.btn_cancelk);
        btnsimpan = (Button) findViewById(R.id.btn_simpanr);
        pd = new ProgressDialog(InsertK.this);

        btnsimpan = (Button) findViewById(R.id.btn_simpank);
        btnbatal = (Button) findViewById(R.id.btn_cancelk);

        /*kondisi update / insert*/
        if(update == 1)
        {
            btnsimpan.setText("Update Data");
            id.setText(intent_id);
            nama.setText(intent_nama);
            ras.setText(intent_ras);
            warna.setText(intent_warna);
            jenis_kelamin.setText(intent_jenis_kelamin);

        }


        btnsimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(update == 1)
                {
                    Update_data();
                }else {
                    simpanData();
                }
            }
        });

        btnbatal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent main = new Intent(InsertK.this,MainActivity.class);
                startActivity(main);
            }
        });
    }

    private void Update_data()
    {
        pd.setMessage("Update Data");
        pd.setCancelable(false);
        pd.show();

        StringRequest updateReq = new StringRequest(Request.Method.POST, ServerAPI.UPDK,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pd.cancel();
                        try {
                            JSONObject res = new JSONObject(response);
                            Toast.makeText(InsertK.this, ""+   res.getString("message") , Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        startActivity( new Intent(InsertK.this,MainActivity.class));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.cancel();
                        Toast.makeText(InsertK.this, "Gagal Insert Data", Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("id",id.getText().toString());
                map.put("nama",nama.getText().toString());
                map.put("ras",ras.getText().toString());
                map.put("warna",ras.getText().toString());
                map.put("jk",jenis_kelamin.getText().toString());

                return map;
            }
        };

        AppController.getInstance().addToRequestQueue(updateReq);
    }



    private void simpanData()
    {

        pd.setMessage("Menyimpan Data");
        pd.setCancelable(false);
        pd.show();

        StringRequest sendData = new StringRequest(Request.Method.POST, ServerAPI.INSK,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pd.cancel();
                        try {
                            JSONObject res = new JSONObject(response);
                            Toast.makeText(InsertK.this, ""+   res.getString("message") , Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        startActivity( new Intent(InsertK.this,MainActivity.class));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.cancel();
                        Toast.makeText(InsertK.this, "Gagal Insert Data", Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("id",id.getText().toString());
                map.put("nama",nama.getText().toString());
                map.put("ras",ras.getText().toString());
                map.put("warna",warna.getText().toString());
                map.put("jk",jenis_kelamin.getText().toString());

                return map;
            }
        };

        AppController.getInstance().addToRequestQueue(sendData);
    }
}
