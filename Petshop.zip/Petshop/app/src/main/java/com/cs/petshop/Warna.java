package com.cs.petshop;

import java.io.Serializable;

public class Warna implements Serializable {
    private String id;
    private String warna;

    public Warna() {
    }

    public Warna(String id, String warna) {
        this.id = id;
        this.warna = warna;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getWarna() {
        return warna;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }
}