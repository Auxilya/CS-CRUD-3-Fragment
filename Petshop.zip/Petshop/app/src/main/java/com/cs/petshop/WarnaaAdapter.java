package com.cs.petshop;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class WarnaaAdapter extends RecyclerView.Adapter<WarnaaAdapter.ViewHolder> {

    private Context context;
    private List<Warnaa> list;

    public WarnaaAdapter(Context context, List<Warnaa> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_warna,parent,false);
        ViewHolder viewHolder = new ViewHolder(v);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Warnaa obj = list.get(position);
        holder.id.setText(obj.getId()+". ");
        holder.warna.setText(obj.getWarna());

        holder.md = obj;
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView id, warna;
        Warnaa md;
        private LinearLayout box_linear;

        public ViewHolder(View itemView) {
            super(itemView);

            id = (TextView) itemView.findViewById(R.id.nomorw);
            warna = (TextView)itemView.findViewById(R.id.warna);
            box_linear = itemView.findViewById(R.id.box_linear);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent update = new Intent(context, InsertW.class);
                    update.putExtra("update",1);
                    update.putExtra("id",md.getId());
                    update.putExtra("warna",md.getWarna());

                    context.startActivity(update);
                }
            });
        }
    }
}
