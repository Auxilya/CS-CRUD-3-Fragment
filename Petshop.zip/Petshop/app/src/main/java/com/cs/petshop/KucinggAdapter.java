package com.cs.petshop;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class KucinggAdapter extends RecyclerView.Adapter<KucinggAdapter.ViewHolder> {

    private Context context;
    private List<Kucingg> list;

    public KucinggAdapter(Context context, List<Kucingg> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_kucing,parent,false);
        ViewHolder viewHolder = new ViewHolder(v);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Kucingg obj = list.get(position);
        holder.id.setText(obj.getId());
        holder.nama.setText("Nama: " + obj.getNama());
        holder.rask.setText("Ras: " + obj.getRas());
        holder.warnak.setText("Warna: " + obj.getWarna());
        holder.jkk.setText("Jenis Kelamin: " + obj.getJenis_kelamin());

        holder.md = obj;
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView id, nama, rask, warnak, jkk;
        Kucingg md;
        private LinearLayout box_linear;

        public ViewHolder(View itemView) {
            super(itemView);

            id = (TextView) itemView.findViewById(R.id.id);
            nama = (TextView) itemView.findViewById(R.id.nama);
            rask = (TextView)itemView.findViewById(R.id.rask);
            warnak =(TextView) itemView.findViewById(R.id.warnak);
            jkk = (TextView) itemView.findViewById(R.id.jkk);
            box_linear = itemView.findViewById(R.id.box_linear);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent update = new Intent(context, InsertK.class);
                    update.putExtra("update",1);
                    update.putExtra("id",md.getId());
                    update.putExtra("nama",md.getNama());
                    update.putExtra("ras",md.getRas());
                    update.putExtra("warna",md.getWarna());
                    update.putExtra("jk",md.getJenis_kelamin());

                    context.startActivity(update);
                }
            });
        }
    }
}
