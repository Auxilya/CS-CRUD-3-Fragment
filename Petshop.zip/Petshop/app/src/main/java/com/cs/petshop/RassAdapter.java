package com.cs.petshop;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class RassAdapter extends RecyclerView.Adapter<RassAdapter.ViewHolder> {

    private Context context;
    private List<Rass> list;

    public RassAdapter(Context context, List<Rass> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ras,parent,false);
        ViewHolder viewHolder = new ViewHolder(v);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Rass obj = list.get(position);
        holder.id.setText(obj.getId()+". ");
        holder.ras.setText(obj.getRas());

        holder.md = obj;
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView id, ras;
        Rass md;
        private LinearLayout box_linear;

        public ViewHolder(View itemView) {
            super(itemView);

            id = (TextView) itemView.findViewById(R.id.nomorr);
            ras = (TextView)itemView.findViewById(R.id.ras);
            box_linear = itemView.findViewById(R.id.box_linear);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent update = new Intent(context, InsertR.class);
                    update.putExtra("update",1);
                    update.putExtra("id",md.getId());
                    update.putExtra("ras",md.getRas());

                    context.startActivity(update);
                }
            });
        }
    }
}
