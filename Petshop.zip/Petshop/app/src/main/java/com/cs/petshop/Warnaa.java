package com.cs.petshop;

public class Warnaa {
    private String infoWarna;
    private String  id;
    private String warna;

    public Warnaa() {}

    public Warnaa(String id, String warna) {
        this.id = id;
        this.warna = warna;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getWarna() {
        return warna;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public String getInfoWarna() {
        return infoWarna;
    }

    public void setInfoWarna(String infoWarna) {
        this.infoWarna = infoWarna;
    }
}